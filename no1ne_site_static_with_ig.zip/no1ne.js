const INSTA_URL = 'https://instagram.com/yourhandle';

(function(){
  const btn = document.querySelector('.dropbtn');
  const menu = document.getElementById('nav-menu');
  if(!btn || !menu) return;
  btn.addEventListener('click',()=>{
    const open = menu.classList.toggle('show');
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  document.addEventListener('click',(e)=>{
    if(!menu.contains(e.target) && !btn.contains(e.target)){
      menu.classList.remove('show'); btn.setAttribute('aria-expanded','false');
    }
  });
  document.addEventListener('keydown',(e)=>{
    if(e.key === 'Escape'){menu.classList.remove('show'); btn.setAttribute('aria-expanded','false');}
  });
  menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{
    menu.classList.remove('show'); btn.setAttribute('aria-expanded','false');
  }));
  const y = document.getElementById('year'); if(y) y.textContent = new Date().getFullYear();
})();

// Apply Instagram URL to any .insta-link anchors
document.querySelectorAll('.insta-link').forEach(a => a.href = INSTA_URL);
