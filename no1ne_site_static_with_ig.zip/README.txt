# nø•1ne — Static Preview Site

This folder contains a multi‑page static site you can open locally to preview the experience.

## Pages
- index.html  → Home
- about.html  → About
- events.html → Events
- gallery.html→ Gallery
- contact.html→ Request Invite

## How to view
1) Unzip the package.
2) Double‑click `index.html` to open it in your browser.
   - The header dropdown links navigate between pages.
   - All buttons use the black + red style.
   - Location shows: Miami · NYC · DC.
   - "Host a night" removed.
   - Hero line: “for the few who know. For the fewer who belong”
3) If your browser blocks local JS for some reason, try Chrome or serve the folder with a simple server:
   - Python: `python3 -m http.server 8080` and open http://localhost:8080

## Next steps (optional)
- I can convert this to a Next.js project (with SEO, analytics, Mailchimp/Klaviyo forms, and a simple RSVP API) on request.